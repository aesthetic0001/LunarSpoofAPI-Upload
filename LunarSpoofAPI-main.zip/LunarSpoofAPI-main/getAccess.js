const ygg = require('yggdrasil')();

ygg.auth({
    user: 'mokkiman92@gmail.com', //Username
    pass: 'itikka92', //Password
    requestUser: false //Optional. Request the user object to be included in response
}).then(
    (response)=>{
        console.log(response)
    },
    (error)=>{}
);
