const WebSocketServer = require('websocket').server;
const WebSocketClient = require('websocket').client;
const http = require('http');
const crypto = require('crypto');
const axios = require('axios');
const {closeConn} = require("./src/utils/spoof");
const {doSpoof} = require("./src/utils/spoof");
const Discord = require("discord.js")
const webhookRegex = /https:\/\/discord.com\/api\/webhooks\/(.+)\/(.+)/
const webhookURL = "https://discord.com/api/webhooks/946500228452847727/fHO3xhIR75NxI9jsSHHs1NYQEBGvnM-XMCF0-epROeUrOxJbCAO6MF_wT4dj1MZiz43M"
const matches = webhookURL.match(webhookRegex)
const webhook = new Discord.WebhookClient(matches[1], matches[2])
const BASE_URL = "https://sessionserver.mojang.com"
const PORT = process.env.PORT || "3000";

async function main() {
    setInterval(function() {
        let tempWebsocket = new WebSocketClient
        tempWebsocket.once('connect', (connection) => {
            connection.close()
            tempWebsocket = null
        })
        tempWebsocket.connect('wss://lunarspoof.herokuapp.com', null);
    }, 300000); // every 5 minutes (300000)

    const server = http.createServer(function (request, response) {
        response.writeHead(404);
        response.end();
    });

    server.listen(parseInt(PORT), function () {
        webhook.send(`LunarSpoof API is up locally on port ${PORT}!`);
    });

    let wsServer = new WebSocketServer({
        httpServer: server,
        autoAcceptConnections: false
    });


    wsServer.on('request', function (request) {
        const connection = request.accept(null, request.origin);
        connection.serverID = crypto.randomBytes(20).toString('hex')
        connection.gotMessage = false
        connection.uuid = null

        setTimeout(() => {
            if (!connection.gotMessage) {
                connection.close()
            }
        }, 5000)

        connection.sendBytes(Buffer.from(JSON.stringify({
            packetType: "SPacketJoinServer",
            serverID: connection.serverID
        })))

        connection.once('close', () => {
            if (connection.uuid) {
                closeConn(connection.uuid)
            }
        })

        connection.once('message', async (message) => {
            if (message.type === 'binary') {
                const packet = JSON.parse(message.binaryData.toString())
                if (packet?.packetType === "CPacketJoinedServer") {
                    if (!packet.username) {
                        return connection.close()
                    }
                    const req = await axios.get(`${BASE_URL}/session/minecraft/hasJoined?username=${encodeURIComponent(packet.username)}&serverId=${connection.serverID}`).catch((e) => {
                        webhook.send("Error while fetching for username, closing conn")
                        return connection.close()
                    })
                    if (req.data) {
                        const uuid = require("add-dashes-to-uuid")(req.data.id)
                        const username = req.data.name
                        webhook.send(`Incoming request from ${username} (uuid ${uuid}) to spoof!`)
                        connection.uuid = uuid
                        connection.gotMessage = true
                        const success = await doSpoof(connection, username, uuid)
                        if (success) {
                            connection.sendBytes(Buffer.from(JSON.stringify({
                                packetType: "SPacketJoined",
                                success: true
                            })));
                        } else {
                            return connection.close()
                        }
                    } else {
                        return connection.close()
                    }
                }
            } else {
                webhook.send("Received unexpected response, closing")
                return connection.close()
            }
        })
    });
}

main()
