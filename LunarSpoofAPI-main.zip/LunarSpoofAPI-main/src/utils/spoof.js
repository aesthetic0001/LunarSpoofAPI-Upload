const {getSID} = require("./getSID");
const {encrypt} = require("./encryption");
const WebSocketClient = require('websocket').client;
const crypto = require('crypto')
const spoofers = {}

async function awaitEvent(object, event, timeout) {
    return new Promise(async (resolve) => {
        function onEvent(data) {
            clearTimeout(timeoutObj)
            resolve(data)
        }

        const timeoutObj = setTimeout(() => {
            object.removeListener(event, onEvent)
            resolve(null)
        }, timeout)

        object.once(event, onEvent)
    })
}

function closeConn(uuid) {
    return spoofers[uuid].close()
}

async function doSpoof(connection, username, uuid) {
    return new Promise((resolve) => {
        if (Object.keys(spoofers).find((key) => key === uuid)) {
            return resolve(true)
        }
        const authData = {
            pKey: null,
            rBytes: null,
            JWT: null,
            sharedSecret: crypto.randomBytes(16)
        }

        const clients = {
            auth: new WebSocketClient(),
            assets: new WebSocketClient()
        }

        // auth websocket server
        clients.auth.once('connect', async (authConn) => {
            spoofers[uuid] = authConn
            authConn.on('message', async (message) => {
                const packet = JSON.parse(message.binaryData.toString())
                if (packet.packetType === "SPacketEncryptionRequest") {
                    awaitEvent(connection, 'message', 8000).then((message) => {
                        const receivedPacket = JSON.parse(message.binaryData.toString()) ?? null
                        if (receivedPacket?.packetType === "CPacketJoinedAuth") {
                            const data = {
                                packetType: "CPacketEncryptionResponse",
                                secretKey: encrypt(authData.sharedSecret, packet.publicKey).toString('base64url'),
                                publicKey: encrypt(Buffer.from(packet.randomBytes, 'base64'), packet.publicKey).toString('base64url')
                            }
                            authConn.sendBytes(Buffer.from(JSON.stringify(data)))
                        } else {
                            connection.close()
                            authConn.close()
                        }
                    })
                    connection.sendBytes(Buffer.from(JSON.stringify({
                        packetType: "SPacketJoinRequest",
                        lunarServerID: getSID(authData.sharedSecret.toString('base64'), packet.publicKey)
                    })))
                    // trust the user is right
                } else if (packet.packetType === "SPacketAuthenticatedRequest") {
                    authData.JWT = packet.jwtKey
                    clients.assets.connect("wss://assetserver.lunarclientprod.com/connect", null, null, {
                        "accountType": "MOJANG",
                        "version": "v1_8",
                        "gitCommit": "2ef0680874b1d11cea10a4b969c6f5ec1f804d70",
                        "branch": "master",
                        "os": "Windows 10",
                        "arch": "",
                        "server": "aesthetic.gg",
                        "launcherVersion": "2.4.1",
                        "username": username,
                        "playerId": uuid,
                        "Authorization": authData.JWT,
                        "clothCloak": "false",
                        "hwid": "myHWID"
                    })
                    authConn.close()
                }
            });
        });

        // assets WS
        clients.assets.once('connect', async (assetsConn) => {
            assetsConn.sendBytes(Buffer.from("BgALaHlwaXhlbC5uZXQ=", 'base64'))
            setInterval(() => {
                assetsConn.sendBytes(Buffer.from("QAEOc2t5YmxvY2thZGRvbnMAAA==", 'base64'))
            }, 60)
            return resolve(true)
        });

        clients.auth.connect('wss://authenticator.lunarclientprod.com', null, null, {
            "username": username,
            "playerId": uuid,
        });
    })
}

module.exports = {
    doSpoof,
    closeConn
}

