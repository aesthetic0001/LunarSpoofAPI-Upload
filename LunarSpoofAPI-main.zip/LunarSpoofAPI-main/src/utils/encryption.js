const crypto = require('crypto')

function mcPubKeyToPem(mcPubKeyBuffer) {
    let pem = '-----BEGIN PUBLIC KEY-----\n'
    let base64PubKey = mcPubKeyBuffer.toString('base64')
    const maxLineLength = 64
    while (base64PubKey.length > 0) {
        pem += base64PubKey.substring(0, maxLineLength) + '\n'
        base64PubKey = base64PubKey.substring(maxLineLength)
    }
    pem += '-----END PUBLIC KEY-----'
    return pem
}


function encrypt(data, pkey) {
    const pkeyBuff = Buffer.from(pkey, "base64")
    return crypto.publicEncrypt(
        {
            key: mcPubKeyToPem(pkeyBuff),
            padding: crypto.constants.RSA_PKCS1_PADDING,
        },
        data
    )
}

module.exports = {
    encrypt
}
