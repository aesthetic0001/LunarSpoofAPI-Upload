const {createHash} = require('crypto')

// src: node-yggdrasil
function performTwosCompliment (buffer) {
    let carry = true
    let i, newByte, value
    for (i = buffer.length - 1; i >= 0; --i) {
        value = buffer.readUInt8(i)
        newByte = ~value & 0xff
        if (carry) {
            carry = newByte === 0xff
            buffer.writeUInt8(carry ? 0 : newByte + 1, i)
        } else {
            buffer.writeUInt8(newByte, i)
        }
    }
}

function mcHexDigest (hash, encoding) {
    if (!(hash instanceof Buffer)) {
        hash = (Buffer).from(hash, encoding)
    }
    // check for negative hashes
    const negative = (hash).readInt8(0) < 0
    if (negative) performTwosCompliment(hash)
    return (negative ? '-' : '') + hash.toString('hex').replace(/^0+/g, '')
}


function getSID(skeyEnc, pubkeyEnc) {
    const skey = Buffer.from(skeyEnc, "base64")
    const serverkey = Buffer.from(pubkeyEnc, 'base64url')
    return mcHexDigest(createHash('sha1').update("").update(skey).update(serverkey).digest())
}

module.exports = {
    getSID
}
