const path = require('path')
const {Authflow: PrismarineAuth, Titles} = require('prismarine-auth')
const minecraftFolderPath = require('minecraft-folder-path')

async function authenticate(options) {
    options.profilesFolder = path.join(minecraftFolderPath, 'lunarspoof-cache')

    if (options.authTitle === undefined) {
        options.authTitle = Titles.MinecraftNintendoSwitch
        options.deviceType = 'Nintendo'
    }

    const Authflow = new PrismarineAuth(options.username, options.profilesFolder, options, options.onMsaCode)
    const {token, profile} = await Authflow.getMinecraftJavaToken({fetchProfile: true}).catch(e => {
        if (options.password) console.warn('Sign in failed, try removing the password field\n')
        if (e.toString().includes('Not Found')) console.warn(`Please verify that the account ${options.username} owns Minecraft\n`)
        throw e
    })

    if (!profile || profile.error) throw Error(`Failed to obtain profile data for ${options.username}, does the account own minecraft?`)

    return {
        accessToken: token,
        selectedProfile: profile,
        availableProfile: [profile]
    }
}

module.exports = {
    authenticate
}
