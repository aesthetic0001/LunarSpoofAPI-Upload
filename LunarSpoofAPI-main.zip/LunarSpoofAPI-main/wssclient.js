const axios = require("axios");
const {authenticate} = require("./lunarspoof");
const WebSocketClient = require('websocket').client;
const client = new WebSocketClient();
const ygg = require('yggdrasil')();

const email = ""
const password = ""

async function spoofLunar(mode) {
    let response
    if (mode === "mojang") {
        response = await ygg.auth({
            user: email,
            pass: password,
            requestUser: false
        })
    } else {
        response = await authenticate({
            username: email,
            password: password
        })
    }

    const accessToken = response.accessToken
    const uuid = response.selectedProfile.id
    const username = response.selectedProfile.name

    client.on('connectFailed', function (error) {
        console.log('Connect Error: ' + error.toString());
    });

    client.on('connect', function (connection) {
        console.log('WebSocket Client Connected');
        connection.on('message', async function (message) {
            const packet = JSON.parse(message.binaryData.toString())
            const {packetType} = packet
            console.log(`Server -> Client: ${packetType}`)
            switch (packetType) {
                case "SPacketJoinServer": {
                    // join the serverID that the ws server provides us
                    // this is so that the ws server can obtain certain info about the account which is needed for spoofing
                    // ie the player's uuid
                    await axios.post('https://sessionserver.mojang.com/session/minecraft/join', {
                        accessToken,
                        selectedProfile: uuid,
                        serverId: packet.serverID
                    }, {
                        headers: {
                            'User-Agent': `aes-auth/6969`,
                            'Content-Type': 'application/json'
                        }
                    })
                    sendBytes(connection, {
                        packetType: "CPacketJoinedServer",
                        username: username
                    })
                    break;
                }
                case "SPacketJoinRequest": {
                    // a join request to the lunar websocket
                    // ws server returns "lunarServerID", the serverID that we need to join to start the spoofing process
                    await axios.post('https://sessionserver.mojang.com/session/minecraft/join', {
                        accessToken,
                        selectedProfile: uuid,
                        serverId: packet.lunarServerID
                    }, {
                        headers: {
                            'User-Agent': `aes-auth/6969`,
                            'Content-Type': 'application/json'
                        }
                    })
                    sendBytes(connection, {
                        packetType: "CPacketJoinedAuth",
                        success: true
                    })
                    break;
                }
                case "SPacketJoined": {
                    // we have started spoofing lunar!
                    console.log("Started spoofing!")
                }
            }
        });
    });

    client.connect('wss://lunarspoof.herokuapp.com', null);
}

function sendBytes(connection, json) {
    console.log(`Client -> Server: ${json.packetType}`)
    return connection.sendBytes(Buffer.from(JSON.stringify(json)))
}

spoofLunar("microsoft")
